import os
import time
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms as T
from torchvision.models import mobilenet_v3_small, MobileNet_V3_Small_Weights

torch.set_num_threads(4)
print("шак1")
norm = T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
tf = T.Compose([T.Resize(256), T.CenterCrop(224), T.ToTensor(), norm])
train_dir = 'C:/Users/user/Desktop/data/hymenoptera_data/train'
val_dir = 'C:/Users/user/Desktop/data/hymenoptera_data/val'

if not os.path.exists(train_dir):
    print(f"нет датасета в  {train_dir}")
else:
    tr = datasets.ImageFolder(train_dir, tf)
    va = datasets.ImageFolder(val_dir, tf)
    print(f"Классы: {tr.classes} | Обучение: {len(tr)} картинок | Валидация: {len(va)} картинок")

    print("\nшак2")
    tf_small = T.Compose([T.Resize(96), T.CenterCrop(96), T.ToTensor()])
    tr_small = datasets.ImageFolder(train_dir, tf_small)
    va_small = datasets.ImageFolder(val_dir, tf_small)
    
    train_loader = DataLoader(tr_small, batch_size=32, shuffle=True)
    val_loader = DataLoader(va_small, batch_size=32, shuffle=False)

    cnn_model = nn.Sequential(
        nn.Conv2d(3, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2), # 48x48
        nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2), # 24x24
        nn.Flatten(),
        nn.Linear(32 * 24 * 24, 2)
    )
    
    opt_cnn = torch.optim.Adam(cnn_model.parameters(), lr=1e-3)
    loss_fn = nn.CrossEntropyLoss()
    
    t_start = time.time()
    for ep in range(5):
        cnn_model.train()
        for x, y in train_loader:
            opt_cnn.zero_grad()
            loss_fn(cnn_model(x), y).backward()
            opt_cnn.step()
            
    cnn_model.eval()
    correct = 0
    with torch.no_grad():
        for x, y in val_loader:
            correct += (cnn_model(x).argmax(1) == y).sum().item()
    
    cnn_acc = correct / len(va_small)
    cnn_time = time.time() - t_start
    print(f"CNN с нуля за 5 эпох | Val Acc: {cnn_acc:.4f} | Время: {cnn_time:.1f}с")

    print("\nшак3")
    body = mobilenet_v3_small(weights=MobileNet_V3_Small_Weights.DEFAULT)
    body.classifier = nn.Identity()
    body.eval()

    def extract(ds):
        xs, ys = [], []
        with torch.no_grad():
            for x, y in DataLoader(ds, batch_size=32, shuffle=False):
                xs.append(body(x))
                ys.append(y)
        return torch.cat(xs), torch.cat(ys)

    t_ext = time.time()
    Ftr, ytr = extract(tr)
    Fva, yva = extract(va)
    print(f"Формат матрицы признаков обучения: {Ftr.shape} | Время извлечения: {time.time() - t_ext:.1f}с")
    torch.save((Ftr, ytr, Fva, yva), 'features.pt')

    print("\nшак4")
    head = nn.Linear(576, 2)
    opt_head = torch.optim.Adam(head.parameters(), lr=1e-3)
    
    t_head = time.time()
    for ep in range(100):
        opt_head.zero_grad()
        loss = loss_fn(head(Ftr), ytr)
        loss.backward()
        opt_head.step()
        
    head.eval()
    with torch.no_grad():
        val_acc = (head(Fva).argmax(1) == yva).float().mean().item()
    head_time = time.time() - t_head
    
    params_count = sum(p.numel() for p in head.parameters())
    print(f"Голова MobileNet | Val Acc: {val_acc:.4f} | Время: {head_time:.2f}с")
    print(f"Количество обучаемых параметров: {params_count}")
    print("\n" + "="*50)
    print(f"{'Архитектура':<25} | {'Val Accuracy':<12} | {'Время обучения':<10}")
    print("-"*50)
    print(f"{'CNN с нуля (96x96)':<25} | {cnn_acc:<12.2%} | {cnn_time:.1f}s")
    print(f"{'MobileNet + голова (224x224)':<25} | {val_acc:<12.2%} | {head_time:.2f}s")
    print("="*50)
    print("\nшак5")
    body.classifier = head
    body.eval()
    
    img, label = va[0]
    with torch.no_grad():
        pred = body(img[None]).argmax(1).item()
    print(f"Проверка модели -> Ожидание: {label} ({va.classes[label]}) | Предсказание: {pred} ({va.classes[pred]})")
    
    torch.save(body.state_dict(), 'ants_bees.pt')
    print("Веса модели сохранены в 'ants_bees.pt'")

import torch.nn.functional as F
from PIL import Image

print("\nшак6")

custom_image_path = 'C:/Users/user/Desktop/data/test123.jpg' 

if not os.path.exists(custom_image_path):
    print(f"нет фотки на пути: {custom_image_path}")
else:
    img_pil = Image.open(custom_image_path).convert('RGB')
    img_tensor = tf(img_pil) 
    body.eval()
    with torch.no_grad():
        logits = body(img_tensor[None]) 
        probs = F.softmax(logits, dim=1)[0] 
        pred_class_idx = logits.argmax(1).item()
    
    pred_class_name = va.classes[pred_class_idx]
    print(f"Файл: {os.path.basename(custom_image_path)}")
    print(f"Предсказание модели: {pred_class_name} (Индекс: {pred_class_idx})")
    print(f"Вероятности классов -> {va.classes[0]}: {probs[0]:.2%}, {va.classes[1]}: {probs[1]:.2%}")
